This is a Plus! Theme based on the Discworld series by Terry Pratchett.

Installation is easy:
1. Copy the file Discworld.theme to the themes folder
2. From there, create a subfolder named "Discworld" (wo the quotes)
   If you sticked to the default settings this should be
   "C:\Program Files\Plus!\Themes\Discworld" (again wo the quotes)
3. Copy logo.sys to the rootdirectory of your C: drive
4. Copy logow.sys and logos.sys to your Win95 folder
5. Copy Comic.ttf to the Win95 Fonts folder to install it
6. Copy every other file to the Discworld folder (see step 2.)
7. Select the theme, and thats it!

Enjoy, and remember: watch out for anyone who TALKS LIKE THIS :) 

Acknowledgements:
The Pratchett Archives at www.LSpace.org for the wallpaper and the sounds,
Somebody else's Pratchett page (can't remember which) for the startup logo, and
Microsoft's home page for the Comic font

A.J. van Kesteren, The Netherlands
Sorry, no E-mail address (yet)