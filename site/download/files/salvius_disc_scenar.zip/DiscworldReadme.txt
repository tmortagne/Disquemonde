The map is based on the map presented in _The Discworld Mapp_, devised by Terry Pratchett and Stephen Briggs. Translated into CTP2 by Scott Nickell. The scenario icon comes from a Discworld desktop theme, about which I have no further information. Great Library text for some of the wonders has been adapted from _GURPS Discworld_ by Terry Pratchett and Phil Masters.

Note: For now, the Rim and the empty space around it are represented as Continental Shelf and Deep Water tiles. In the scenario so far, all naval units are restricted to Shallow Water. In an ideal world, these would be replaced by new terrain types, Rim and Space, with new graphics, and which no units could traverse, but we're not there yet. :-)

Change log:
0.1	Scenario created. 
	Civilizations updated to reflect Discworld civs.
	Units and terrain files changed to use Deep Water as Space. 
	Some wonders given more appropriate names and Great Library texts.

To do:
	Scenario icon
	Add Wyrmberg (barbarian city?) & make it the only city capable of building Dragons
	Add Dragon unit - short-range air unit, can only be built in Wyrmberg
	Rearrange tech tree to reflect the Disc's odd tech development:
		Imp tech (photography, moving pictures, timekeeping, etc)
		Semaphore towers (building, adds to trade)
		L-space Theory currently gives Computer Center, which is anachronistic
		Computers in Discworld include Hex and stone circles - make available earlier
		Advance which allows HEM Building should be prereq for Computers, and " " "
		Magic/Sourcery?
	Develop scenario based on recent/current situation - cities, tech, etc.
	Develop new Rim and Space tiles, as above
	SLIC scripts to raise/lower Leshp at appropriate intervals